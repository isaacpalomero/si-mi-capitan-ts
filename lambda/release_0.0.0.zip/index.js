"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aplcard_1 = require("./aplcard");
const ask_sdk_core_1 = require("ask-sdk-core");
const modules = require("./modules");
const persistenceAdapter = getPersistenceAdapter("si-mi-capitan");
class LaunchRequestHandler {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === "LaunchRequest";
    }
    handle(handlerInput) {
        const { attributesManager } = handlerInput;
        const sessionAttributes = attributesManager.getSessionAttributes();
        sessionAttributes.id = 1;
        sessionAttributes.reputacion = 50;
        sessionAttributes.tesoro = 50;
        sessionAttributes.vueltas = 0;
        const module = getModule(1);
        const speechText = module.question;
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withStandardCard("Sí mi Capitán", module.question, module.image)
            .getResponse();
    }
}
class YesIntentHandler {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === "IntentRequest"
            && handlerInput.requestEnvelope.request.intent.name === "AMAZON.YesIntent";
    }
    handle(handlerInput) {
        const { attributesManager } = handlerInput;
        const sessionAttributes = attributesManager.getSessionAttributes();
        const moduleId = sessionAttributes.id;
        const module = getModule(moduleId);
        const nextModule = getNextModule(moduleId);
        if (nextModule) {
            sessionAttributes.id = nextModule.id;
        }
        let speechText;
        calculateGameVariables(sessionAttributes, module.yes.variable1, module.yes.variable2);
        if (sessionAttributes.reputacion === 100 || sessionAttributes.reputacion === 0 || sessionAttributes.tesoro === 100 || sessionAttributes.tesoro === 0) {
            speechText = "Tu reputación es de " + sessionAttributes.reputacion + " y tu tesoro de " + sessionAttributes.tesoro + ". Lamentablemente no has sobrevivido al viaje! Inténtalo otra vez! Hasta la próxima!";
            return handlerInput.responseBuilder
                .speak(speechText)
                .getResponse();
        }
        speechText = module.yes.answer;
        if (module.yes.warning) {
            speechText += module.yes.warning;
        }
        if (module.audio) {
            speechText += module.audio;
        }
        if (nextModule) {
            speechText += nextModule.question;
            handlerInput.responseBuilder.reprompt(speechText);
        }
        return handlerInput.responseBuilder
            .speak(speechText)
            .getResponse();
    }
}
class NoIntentHandler {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === "IntentRequest"
            && handlerInput.requestEnvelope.request.intent.name === "AMAZON.NoIntent";
    }
    handle(handlerInput) {
        const { attributesManager } = handlerInput;
        const sessionAttributes = attributesManager.getSessionAttributes();
        const moduleId = sessionAttributes.id;
        const module = getModule(moduleId);
        const nextModule = getNextModule(moduleId);
        if (nextModule) {
            sessionAttributes.id = nextModule.id;
        }
        let speechText;
        calculateGameVariables(sessionAttributes, module.no.variable1, module.no.variable2);
        if (sessionAttributes.reputacion === 100 || sessionAttributes.reputacion === 0 || sessionAttributes.tesoro === 100 || sessionAttributes.tesoro === 0) {
            speechText = "Tu reputación es de " + sessionAttributes.reputacion + " y tu tesoro de " + sessionAttributes.tesoro + ". Lamentablemente no has sobrevivido al viaje! Inténtalo otra vez! Hasta la próxima!";
            return handlerInput.responseBuilder
                .speak(speechText)
                .getResponse();
        }
        speechText = module.no.answer;
        module.no.warning ? speechText += module.no.warning : speechText;
        if (module.audio) {
            speechText += module.audio;
        }
        if (nextModule) {
            speechText += nextModule.question;
            handlerInput.responseBuilder.reprompt(speechText);
        }
        return handlerInput.responseBuilder
            .speak(speechText)
            .getResponse();
    }
}
class HelpIntentHandler {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === "IntentRequest"
            && handlerInput.requestEnvelope.request.intent.name === "AMAZON.HelpIntent";
    }
    handle(handlerInput) {
        const speechText = "Solo tienes que contestar si o no durante el juego. Elige con sabiduría!";
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .getResponse();
    }
}
class CancelAndStopIntentHandler {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === "IntentRequest"
            && (handlerInput.requestEnvelope.request.intent.name === "AMAZON.CancelIntent"
                || handlerInput.requestEnvelope.request.intent.name === "AMAZON.StopIntent");
    }
    handle(handlerInput) {
        const { attributesManager } = handlerInput;
        const sessionAttributes = attributesManager.getSessionAttributes();
        const speechText = "Tu reputación fue de " + sessionAttributes.reputacion + " y tu tesoro de " + sessionAttributes.tesoro + ". Al salir te has caído por la borda así que tendrás que volver a empezar! Hasta la próxima!";
        return handlerInput.responseBuilder
            .speak(speechText)
            .getResponse();
    }
}
class SessionEndedRequestHandler {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === "SessionEndedRequest";
    }
    handle(handlerInput) {
        return handlerInput.responseBuilder.getResponse();
    }
}
class IntentReflectorHandler {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === "IntentRequest";
    }
    handle(handlerInput) {
        const intentName = handlerInput.requestEnvelope.request.intent.name;
        const speechText = `Acabas de activar ${intentName}`;
        return handlerInput.responseBuilder
            .speak(speechText)
            .getResponse();
    }
}
class CustomErrorHandler {
    canHandle() {
        return true;
    }
    handle(handlerInput, error) {
        console.log(`~~~~ Error handled: ${error.message}`);
        const speechText = `Hubo un error. por favor inténtalo otra vez.`;
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .getResponse();
    }
}
function getRandom(arrayOfItems) {
    let i = 0;
    i = Math.floor(Math.random() * arrayOfItems.length);
    return (arrayOfItems[i]);
}
function getModule(moduleId) {
    return modules.game.filter((module) => module.id === moduleId)[0];
}
function getNextModule(moduleId) {
    const module = getModule(moduleId);
    if (module.targets.length === 0) {
        return null;
    }
    const nextTarget = getRandom(module.targets);
    return getModule(nextTarget);
}
function calculateGameVariables(sessionAttributes, reputacionDif, tesoroDif) {
    sessionAttributes.reputacion += reputacionDif;
    sessionAttributes.tesoro += tesoroDif;
    console.log(sessionAttributes);
}
function getPersistenceAdapter(tableName) {
    function isAlexaHosted() {
        return process.env.S3_PERSISTENCE_BUCKET;
    }
    if (isAlexaHosted()) {
        const { S3PersistenceAdapter } = require("ask-sdk-s3-persistence-adapter");
        return new S3PersistenceAdapter({
            bucketName: process.env.S3_PERSISTENCE_BUCKET,
        });
    }
    else {
        const { DynamoDbPersistenceAdapter } = require("ask-sdk-dynamodb-persistence-adapter");
        return new DynamoDbPersistenceAdapter({
            tableName,
            createTable: true,
        });
    }
}
class LoadAttributesRequestInterceptor {
    async process(handlerInput) {
        const { attributesManager, requestEnvelope } = handlerInput;
        if (requestEnvelope.session && requestEnvelope.session.new) {
            const persistentAttributes = await attributesManager.getPersistentAttributes() || {};
            attributesManager.setSessionAttributes(persistentAttributes);
        }
    }
}
class SaveAttributesResponseInterceptor {
    async process(handlerInput, response) {
        if (!response) {
            return;
        }
        const { attributesManager, requestEnvelope } = handlerInput;
        const sessionAttributes = attributesManager.getSessionAttributes();
        const shouldEndSession = (typeof response.shouldEndSession === "undefined" ? true : response.shouldEndSession);
        if (shouldEndSession || requestEnvelope.request.type === "SessionEndedRequest") {
            attributesManager.setPersistentAttributes(sessionAttributes);
            await attributesManager.savePersistentAttributes();
        }
    }
}
const skillBuilders = ask_sdk_core_1.SkillBuilders.custom();
exports.handler = skillBuilders.addRequestHandlers(new LaunchRequestHandler(), new YesIntentHandler(), new NoIntentHandler(), new HelpIntentHandler(), new CancelAndStopIntentHandler(), new SessionEndedRequestHandler(), new IntentReflectorHandler())
    .addRequestInterceptors(new aplcard_1.APLHomeCardRequestInterceptor(), new LoadAttributesRequestInterceptor())
    .addResponseInterceptors(new SaveAttributesResponseInterceptor())
    .addErrorHandlers(new CustomErrorHandler())
    .withPersistenceAdapter(persistenceAdapter)
    .lambda();
//# sourceMappingURL=index.js.map